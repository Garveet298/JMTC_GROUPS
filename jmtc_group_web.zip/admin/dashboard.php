<?php
session_start();
include '../config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Welcome, Admin 👷</h1>
    <p>This is your dashboard. Manage everything related to the JMTC Group here.</p>
</div>

<?php include 'footer.php'; ?>
